# get-thumbnail
Pass a URL to get Thumbnail
