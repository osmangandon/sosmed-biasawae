define(function() {
    return "emojionearea";
});