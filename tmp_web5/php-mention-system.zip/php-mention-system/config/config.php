<?php
define('DBHost', 'localhost');
define('DBName', 'demo');
define('DBUser', 'root');
define('DBPassword', '');
global $DB;
require(dirname(__FILE__)."/PDO.class.php");
$DB = new Db(DBHost, DBName, DBUser, DBPassword);